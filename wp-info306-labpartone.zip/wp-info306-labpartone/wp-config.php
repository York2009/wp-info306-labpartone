<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp_info306_lab_session2' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'HDJexeZeN3P +eFRzy=DX Zf8a9KNdV=`5N,nHpcnmzE|*TT;0G1EW7B3D,4Vn?N' );
define( 'SECURE_AUTH_KEY',  'Yj-E8X?dc:8r*y;eflpOJqAP3;=9Yb,p^_(R,{XQ8t=]MT)sLg]YZQ/y)=[P@np}' );
define( 'LOGGED_IN_KEY',    'J{0zJ*^m)&YeJczs,br54=/F/xRJy#.1~ J:`G-52-#-n~n(=A+A;0!R1#`|^2OU' );
define( 'NONCE_KEY',        'w8Em7=p*JHgshfby:(B-npVt~ZujszOU)P:TS(ZjLFVeGj*i:(n>r>]D&zKr{s@k' );
define( 'AUTH_SALT',        '&buR4x*1M;i~0!m.1uiSGTuIasa#x<%g|fsOk; c~mOe+xVij}Wmn${CSVd;;.%l' );
define( 'SECURE_AUTH_SALT', '_[hZ^n`hcv9-eLE;L^#mkQTcOc|h:D$^;3}J/SoneNE6p4kghqG,uD_lXiAjFU=^' );
define( 'LOGGED_IN_SALT',   'wn+Xx|2;IWlUHaKhGW|bU|bO=L.L52@M;F}:[8znyF1(rw~}]/AJ7OOG)gI0Qd#n' );
define( 'NONCE_SALT',       'M.Qv<?Q&8[BAs-7Uo&l/ZExXOFDMuC_AyogmYJ**+:%Y^yiH)(h,O3K&x2>DgF>>' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
